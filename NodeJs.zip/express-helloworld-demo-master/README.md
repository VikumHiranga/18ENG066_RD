Simplest Express Demo
=====================

```
npm install
```

Run:

```
node index.js
```

Then visit: 

1. <http://localhost:3000>, you will see `Hello, world!`
2. <http://localhost:3000/hello/Freewind>,, you will see `Hello, Freewind`